package com.currency;

public class USDollar implements Currency{

	@Override
	public String getSymbol() {
		return "$";
	}
}
