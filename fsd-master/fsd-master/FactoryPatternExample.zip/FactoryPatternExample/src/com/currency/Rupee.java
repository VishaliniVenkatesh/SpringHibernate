package com.currency;

class Rupee implements Currency {
    @Override
    public String getSymbol() {
           return "Rs.";
    }
}


