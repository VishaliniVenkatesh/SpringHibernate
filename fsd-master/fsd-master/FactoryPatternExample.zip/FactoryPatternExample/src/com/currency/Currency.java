package com.currency;

interface Currency {
    String getSymbol();
}

