package com.currency;

public class ChineseYuan implements Currency{

	@Override
	public String getSymbol() {
		return "�";
	}

}
