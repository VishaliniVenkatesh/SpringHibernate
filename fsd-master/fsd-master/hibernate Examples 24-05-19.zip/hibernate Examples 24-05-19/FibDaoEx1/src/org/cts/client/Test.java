package org.cts.client;

import org.cts.dao.EmpDao;
import org.cts.dao.EmpDaoImpl;
import org.cts.entities.Emp;

public class Test {
	public static void main(String[] args) {
		EmpDao dao=new EmpDaoImpl();
		/*List<Emp> emps=dao.getAll();
		System.out.println("the employee objects are");
		for(Emp e:emps)
		{
			System.out.println(e.getEno()+"\t"+e.getName()+"\t"+e.getAddress());
		}*/
		//deleting the object
		/*dao.delete(1);
		System.out.println("object deleted successfully");*/
		
		//updating the object
		
		Emp e=dao.get(2);
		e.setAddress("coibatore");
		dao.update(e);
		System.out.println("successfully updated");
	}
}
