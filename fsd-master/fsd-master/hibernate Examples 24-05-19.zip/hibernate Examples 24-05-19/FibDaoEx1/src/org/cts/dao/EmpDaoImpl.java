package org.cts.dao;

import java.util.List;

import org.cts.entities.Emp;
import org.cts.util.HibUtil;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class EmpDaoImpl implements EmpDao {
	Transaction tx=null;
	@Override
	public Integer save(Emp e) {
		Integer id=null;
		Session session=HibUtil.getSession();
		try
		{
			tx=session.beginTransaction();
			id=(Integer)session.save(e);
			tx.commit();
		}
		catch(Exception e1)
		{
			tx.rollback();
		}
		finally
		{
			session.close();
		}
		return id;
	}

	@Override
	public Emp get(int eno) {
		Session session=HibUtil.getSession();
		Emp e=session.get(Emp.class, eno);
		session.close();
		return e;
	}

	@Override
	public List<Emp> getAll() {
		Session session=HibUtil.getSession();
		Query query=session.createQuery("select e from org.cts.entities.Emp e");
		List<Emp> emps=query.list();
		session.close();
		return emps;
	}

	@Override
	public void delete(int eno) {
		Session session=HibUtil.getSession();
		Emp e=session.get(Emp.class, eno);
		try {
			tx=session.beginTransaction();
			session.delete(e);
			tx.commit();
			session.close();
		} catch (Exception e2) {
			tx.rollback();
		}
		finally{
			session.close();
		}
		
	}

	@Override
	public void update(Emp e) {
		Session session=HibUtil.getSession();
		try {
			tx=session.beginTransaction();
			session.saveOrUpdate(e);
			tx.commit();
			session.close();
		} catch (Exception e2) {
			tx.rollback();
		}
		finally
		{
			session.close();
		}
		
		
	}

}
