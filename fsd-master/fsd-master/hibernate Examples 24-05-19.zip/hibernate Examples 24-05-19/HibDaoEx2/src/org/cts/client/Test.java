package org.cts.client;

import org.cts.dao.EmpDao;
import org.cts.dao.EmpDaoImpl;
import org.cts.entities.Emp;

public class Test {
	public static void main(String[] args) {
		EmpDao dao=new EmpDaoImpl();
		/*int i=dao.delete(3);
		if(i>0)
			System.out.println("successfully deleted");*/
		//getting the object
		Emp e=dao.get(2);
		System.out.println(e.getEno()+"\t"+e.getName()+"\t"+e.getAddress());
		
		
	}
}
