package org.cts.dao;

import java.util.List;

import org.cts.entities.Emp;

public interface EmpDao {
	Integer save(Emp e);
	Emp get(int eno);
	List<Emp> getAll();
	int delete(int eno);
	void update(Emp e);

}
