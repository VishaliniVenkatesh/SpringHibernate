package cts.ajax.service;



import cts.ajax.beans.User;
import cts.ajax.dao.UserDao;
import cts.ajax.dao.UserDaoImpl;

public class UserServiceImpl implements UserService {
	
	UserDao dao=new UserDaoImpl();
	public User validateUser(int userid) {
		User user=dao.validateUser(userid);
		return user;
	}
}
