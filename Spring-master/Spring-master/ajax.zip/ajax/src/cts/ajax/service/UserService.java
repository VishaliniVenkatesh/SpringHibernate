package cts.ajax.service;

import cts.ajax.beans.User;



public interface UserService {
	
	User validateUser(int userid);
}
