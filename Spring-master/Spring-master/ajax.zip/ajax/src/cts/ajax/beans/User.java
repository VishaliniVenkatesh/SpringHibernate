package cts.ajax.beans;

public class User {
	private int userid;
	String name;
	public User()
	{
	
	}
	
	public User(int userid, String name) {
		super();
		this.userid = userid;
		this.name = name;
	}

	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
