package cts.ajax.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import cts.ajax.beans.User;
import cts.ajax.utils.DBUtil;
import cts.ajax.utils.DBConstants;
public class UserDaoImpl implements UserDao{

	@Override
	public User validateUser(int userid) {

		Connection con=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		User user=null;
		try {
			con=DBUtil.getConnection(DBConstants.DRIVER, DBConstants.URL, DBConstants.UNAME, DBConstants.PWD);
			pst=con.prepareStatement("select * from user where userid=?");
			pst.setInt(1, userid);
			rs=pst.executeQuery();
			rs.next();
			user=new User(rs.getInt(1), rs.getString(2));
			con.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return user;
	}

}
