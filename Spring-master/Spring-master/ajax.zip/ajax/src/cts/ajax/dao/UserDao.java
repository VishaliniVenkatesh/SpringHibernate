package cts.ajax.dao;

import cts.ajax.beans.User;

public interface UserDao {
	User validateUser(int userid);
}
