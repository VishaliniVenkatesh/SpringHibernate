package cts.ajax.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cts.ajax.beans.User;

import cts.ajax.service.UserService;
import cts.ajax.service.UserServiceImpl;




@WebServlet("/UserController")
public class UserController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	UserService service=new UserServiceImpl();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String msg="";
		System.out.println(request.getParameter("userid"));
		int id=Integer.parseInt(request.getParameter("userid"));
		System.out.println(id);
		User user=service.validateUser(id);
		System.out.println(user);
		if(user!=null)
		{
			msg=msg+"user allready existed with id "+id;
			
		}
		out.println(msg);
		
		out.close();
	}

}
